Change database configurations
  goto Handlers folder then edit "connection.php"
Change Database and DataFlow Settings
  goto Handlers folder then edit "ControllerUserData.php"
Change Emails for OTPs
  goto Handlers folder then edit "ControllerUserData.php"

DATAFLOW FOR THE WHOLE PROJECT IS STORED IN THE "ControllerUserData.php" FILE

NRC AND PROFILE PHOTO UPLOADS ARE CONTROLLED IN THE FOLLOWING FILES;
   1. imageupload.php
   2. nrcupload.php
   ;
go to line 15 of both files (imageupload.php and nrcupload.php) to change the folders for storing images

EDIT THE FILES ACCORDINGLY FOR IT TO FUNCTION PROPERLY ANY MISTAKES IN SPELLING WILL ECHO ERRORS

THIS PROJECT IS CREATED USING PHP MySQL AND CSS