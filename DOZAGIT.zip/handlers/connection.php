<?php 
$con = mysqli_connect('localhost', 'ydo', 'Welcome@2021', 'loansbay');
?>